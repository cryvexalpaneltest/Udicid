"use client";

export type TabId = "sessions" | "ai" | "other" | "profile";

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: "sessions", label: "سشن‌ها", icon: "⏱" },
  { id: "ai", label: "تحلیل هوشمند", icon: "🤖" },
  { id: "other", label: "تحلیل‌ها", icon: "📊" },
  { id: "profile", label: "پروفایل", icon: "👤" },
];

export default function TabBar({
  active,
  onChange,
}: {
  active: TabId;
  onChange: (t: TabId) => void;
}) {
  return (
    <nav className="fixed bottom-0 inset-x-0 glass border-t border-border px-2 py-2 flex justify-around z-20">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-lg text-xs transition-colors ${
            active === tab.id ? "text-accent" : "text-muted"
          }`}
        >
          <span className="text-base leading-none">{tab.icon}</span>
          {tab.label}
        </button>
      ))}
    </nav>
  );
}

"use client";

import { createContext, useContext, useEffect, useState } from "react";

type TgProfile = {
  telegram_id: string;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  photo_url: string | null;
  settings: Record<string, unknown>;
};

type Ctx = {
  ready: boolean;
  error: string | null;
  profile: TgProfile | null;
  initData: string;
  refreshProfile: () => Promise<void>;
};

const TelegramContext = createContext<Ctx>({
  ready: false,
  error: null,
  profile: null,
  initData: "",
  refreshProfile: async () => {},
});

export function useTelegram() {
  return useContext(TelegramContext);
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        ready: () => void;
        expand: () => void;
        initData: string;
        colorScheme: string;
        themeParams: Record<string, string>;
        initDataUnsafe?: { user?: unknown };
      };
    };
  }
}

export default function TelegramProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<TgProfile | null>(null);
  const [initData, setInitData] = useState("");

  async function authenticate(data: string) {
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ initData: data }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "خطا در احراز هویت");
      setProfile(json.profile);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setReady(true);
    }
  }

  async function refreshProfile() {
    if (!initData) return;
    const res = await fetch(`/api/profile?initData=${encodeURIComponent(initData)}`);
    const json = await res.json();
    if (res.ok) setProfile(json.profile);
  }

  useEffect(() => {
    const tg = window.Telegram?.WebApp;
    if (!tg) {
      setError("این برنامه فقط داخل تلگرام قابل استفاده است.");
      setReady(true);
      return;
    }
    tg.ready();
    tg.expand();
    setInitData(tg.initData);
    if (!tg.initData) {
      setError("initData از تلگرام دریافت نشد.");
      setReady(true);
      return;
    }
    authenticate(tg.initData);
  }, []);

  return (
    <TelegramContext.Provider value={{ ready, error, profile, initData, refreshProfile }}>
      {children}
    </TelegramContext.Provider>
  );
}

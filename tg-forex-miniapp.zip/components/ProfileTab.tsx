"use client";

import { useEffect, useState } from "react";
import { useTelegram } from "./TelegramProvider";

type HistoryItem = {
  symbol: string;
  question: string | null;
  answer: string;
  created_at: string;
};

export default function ProfileTab() {
  const { profile, initData } = useTelegram();
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    if (!initData) return;
    fetch(`/api/profile?initData=${encodeURIComponent(initData)}`)
      .then((r) => r.json())
      .then((json) => {
        if (json.history) setHistory(json.history);
      })
      .catch(() => {});
  }, [initData]);

  if (!profile) return null;

  const fullName = [profile.first_name, profile.last_name].filter(Boolean).join(" ");

  return (
    <div className="space-y-4">
      <div className="glass rounded-xl2 p-5 flex items-center gap-4">
        {profile.photo_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={profile.photo_url}
            alt={fullName}
            className="w-14 h-14 rounded-full object-cover border border-border"
          />
        ) : (
          <div className="w-14 h-14 rounded-full bg-panel2 border border-border flex items-center justify-center text-xl">
            👤
          </div>
        )}
        <div>
          <div className="text-base font-semibold text-gray-50">{fullName || "کاربر تلگرام"}</div>
          {profile.username && (
            <div className="text-sm text-muted mono-num">@{profile.username}</div>
          )}
          <div className="text-[11px] text-muted mt-1">
            شناسه: <span className="mono-num">{profile.telegram_id}</span>
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-gray-200 mb-2">تاریخچه تحلیل‌ها</h3>
        {history.length === 0 && (
          <p className="text-xs text-muted px-1">هنوز تحلیلی درخواست نکرده‌اید.</p>
        )}
        <div className="space-y-2">
          {history.map((h, i) => (
            <div key={i} className="glass rounded-xl2 p-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-accent mono-num">{h.symbol}</span>
                <span className="text-[10px] text-muted mono-num">
                  {new Date(h.created_at).toLocaleDateString("fa-IR")}
                </span>
              </div>
              <p className="text-xs text-gray-300 mt-1.5 line-clamp-3">{h.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";

const OVERLAPS = [
  { title: "همپوشانی توکیو و لندن", range: "۰۸:۰۰ تا ۰۹:۰۰ UTC", note: "نقدینگی متوسط، مناسب جفت‌ارزهای ین" },
  { title: "همپوشانی لندن و نیویورک", range: "۱۳:۰۰ تا ۱۷:۰۰ UTC", note: "بیشترین حجم معاملات روزانه، نوسان بالا" },
  { title: "همپوشانی سیدنی و توکیو", range: "۰۰:۰۰ تا ۰۷:۰۰ UTC", note: "نقدینگی پایین‌تر، حرکات آرام‌تر" },
];

function calcPivots(high: number, low: number, close: number) {
  const pp = (high + low + close) / 3;
  const r1 = 2 * pp - low;
  const s1 = 2 * pp - high;
  const r2 = pp + (high - low);
  const s2 = pp - (high - low);
  const r3 = high + 2 * (pp - low);
  const s3 = low - 2 * (high - pp);
  return { pp, r1, r2, r3, s1, s2, s3 };
}

export default function OtherAnalysisTab() {
  const [high, setHigh] = useState("");
  const [low, setLow] = useState("");
  const [close, setClose] = useState("");
  const [result, setResult] = useState<ReturnType<typeof calcPivots> | null>(null);

  function handleCalc() {
    const h = parseFloat(high);
    const l = parseFloat(low);
    const c = parseFloat(close);
    if (isNaN(h) || isNaN(l) || isNaN(c)) return;
    setResult(calcPivots(h, l, c));
  }

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-200 mb-2">بهترین بازه‌های همپوشانی سشن‌ها</h3>
        <div className="space-y-2">
          {OVERLAPS.map((o) => (
            <div key={o.title} className="glass rounded-xl2 p-3">
              <div className="text-sm text-gray-100">{o.title}</div>
              <div className="text-xs text-accent mono-num mt-0.5">{o.range}</div>
              <div className="text-xs text-muted mt-1">{o.note}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="glass rounded-xl2 p-4 space-y-3">
        <h3 className="text-sm font-semibold text-gray-200">محاسبه‌گر نقاط پیوت (Pivot Points)</h3>
        <div className="grid grid-cols-3 gap-2">
          <input
            value={high}
            onChange={(e) => setHigh(e.target.value)}
            placeholder="High"
            className="bg-panel2 border border-border rounded-lg px-2 py-2 text-sm text-center mono-num outline-none focus:border-accent"
          />
          <input
            value={low}
            onChange={(e) => setLow(e.target.value)}
            placeholder="Low"
            className="bg-panel2 border border-border rounded-lg px-2 py-2 text-sm text-center mono-num outline-none focus:border-accent"
          />
          <input
            value={close}
            onChange={(e) => setClose(e.target.value)}
            placeholder="Close"
            className="bg-panel2 border border-border rounded-lg px-2 py-2 text-sm text-center mono-num outline-none focus:border-accent"
          />
        </div>
        <button
          onClick={handleCalc}
          className="w-full bg-panel2 border border-accent text-accent rounded-lg py-2 text-sm"
        >
          محاسبه
        </button>

        {result && (
          <div className="grid grid-cols-2 gap-2 pt-2 text-xs mono-num">
            <div className="text-danger">R3: {result.r3.toFixed(4)}</div>
            <div className="text-danger">S3: {result.s3.toFixed(4)}</div>
            <div className="text-danger">R2: {result.r2.toFixed(4)}</div>
            <div className="text-danger">S2: {result.s2.toFixed(4)}</div>
            <div className="text-danger">R1: {result.r1.toFixed(4)}</div>
            <div className="text-danger">S1: {result.s1.toFixed(4)}</div>
            <div className="col-span-2 text-accent2 text-center pt-1 border-t border-border">
              PP: {result.pp.toFixed(4)}
            </div>
          </div>
        )}
      </div>

      <p className="text-[11px] text-muted leading-6 px-1">
        این بخش صرفاً جنبه آموزشی و اطلاع‌رسانی دارد و توصیه مالی محسوب نمی‌شود.
      </p>
    </div>
  );
}

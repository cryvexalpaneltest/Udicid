"use client";

import { useEffect, useState } from "react";
import { SESSIONS, getSessionStatus, formatDuration } from "@/lib/sessions";

export default function SessionTimer() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  if (!now) return null;

  return (
    <div className="grid grid-cols-1 gap-3">
      {SESSIONS.map((session) => {
        const status = getSessionStatus(session, now);
        return (
          <div
            key={session.id}
            className="glass rounded-xl2 p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{
                  backgroundColor: status.isOpen ? session.color : "#3a4453",
                  boxShadow: status.isOpen ? `0 0 10px ${session.color}` : "none",
                }}
              />
              <div>
                <div className="text-sm font-medium text-gray-100">{session.nameFa}</div>
                <div className="text-xs text-muted">
                  {status.isOpen ? "بازار باز است" : "بازار بسته است"}
                </div>
              </div>
            </div>

            <div className="text-left">
              <div className="mono-num text-lg font-semibold text-gray-50">
                {formatDuration(status.msUntilChange)}
              </div>
              <div className="text-[11px] text-muted">
                {status.changeType === "close" ? "تا بسته شدن" : "تا باز شدن"}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

"use client";

import { useState } from "react";
import { useTelegram } from "./TelegramProvider";

const QUICK_SYMBOLS = ["XAUUSD", "EURUSD", "GBPUSD", "BTCUSD"];

export default function AIAnalysisTab() {
  const { initData } = useTelegram();
  const [symbol, setSymbol] = useState("XAUUSD");
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function requestAnalysis() {
    setLoading(true);
    setError(null);
    setAnswer(null);
    try {
      const res = await fetch("/api/analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ initData, symbol, question }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "خطا در دریافت تحلیل");
      setAnswer(json.answer);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="glass rounded-xl2 p-4 space-y-3">
        <label className="text-xs text-muted block">نماد / جفت‌ارز</label>
        <input
          value={symbol}
          onChange={(e) => setSymbol(e.target.value.toUpperCase())}
          className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-sm outline-none focus:border-accent mono-num"
          placeholder="EURUSD"
        />
        <div className="flex gap-2 flex-wrap">
          {QUICK_SYMBOLS.map((s) => (
            <button
              key={s}
              onClick={() => setSymbol(s)}
              className={`text-xs px-2.5 py-1 rounded-full border ${
                symbol === s ? "border-accent text-accent" : "border-border text-muted"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        <label className="text-xs text-muted block pt-2">سوال یا زمینه (اختیاری)</label>
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          rows={3}
          className="w-full bg-panel2 border border-border rounded-lg px-3 py-2 text-sm outline-none focus:border-accent resize-none"
          placeholder="مثلاً: روند کوتاه‌مدت این نماد چطور به نظر می‌رسد؟"
        />

        <button
          onClick={requestAnalysis}
          disabled={loading || !symbol}
          className="w-full bg-accent text-bg font-medium rounded-lg py-2.5 text-sm disabled:opacity-50"
        >
          {loading ? "در حال تحلیل..." : "دریافت تحلیل با هوش مصنوعی"}
        </button>
      </div>

      {error && (
        <div className="glass rounded-xl2 p-4 text-sm text-danger border-danger/30">{error}</div>
      )}

      {answer && (
        <div className="glass rounded-xl2 p-4 text-sm leading-7 whitespace-pre-wrap text-gray-100">
          {answer}
        </div>
      )}
    </div>
  );
}

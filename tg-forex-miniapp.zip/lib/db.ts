import { sql } from "@vercel/postgres";
import type { TelegramUser } from "./telegramAuth";

export type UserProfile = {
  telegram_id: string;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  photo_url: string | null;
  settings: Record<string, unknown>;
  created_at: string;
};

export async function ensureSchema() {
  await sql`
    CREATE TABLE IF NOT EXISTS users (
      telegram_id TEXT PRIMARY KEY,
      username TEXT,
      first_name TEXT,
      last_name TEXT,
      photo_url TEXT,
      settings JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS analysis_history (
      id SERIAL PRIMARY KEY,
      telegram_id TEXT NOT NULL REFERENCES users(telegram_id),
      symbol TEXT NOT NULL,
      question TEXT,
      answer TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;
}

export async function upsertUser(user: TelegramUser): Promise<UserProfile> {
  const id = String(user.id);
  const { rows } = await sql<UserProfile>`
    INSERT INTO users (telegram_id, username, first_name, last_name, photo_url)
    VALUES (${id}, ${user.username ?? null}, ${user.first_name ?? null}, ${user.last_name ?? null}, ${user.photo_url ?? null})
    ON CONFLICT (telegram_id)
    DO UPDATE SET
      username = EXCLUDED.username,
      first_name = EXCLUDED.first_name,
      last_name = EXCLUDED.last_name,
      photo_url = EXCLUDED.photo_url
    RETURNING *;
  `;
  return rows[0];
}

export async function getUser(telegramId: string): Promise<UserProfile | null> {
  const { rows } = await sql<UserProfile>`
    SELECT * FROM users WHERE telegram_id = ${telegramId};
  `;
  return rows[0] ?? null;
}

export async function updateUserSettings(
  telegramId: string,
  settings: Record<string, unknown>
): Promise<UserProfile> {
  const { rows } = await sql<UserProfile>`
    UPDATE users SET settings = ${JSON.stringify(settings)}::jsonb
    WHERE telegram_id = ${telegramId}
    RETURNING *;
  `;
  return rows[0];
}

export async function saveAnalysis(
  telegramId: string,
  symbol: string,
  question: string | null,
  answer: string
) {
  await sql`
    INSERT INTO analysis_history (telegram_id, symbol, question, answer)
    VALUES (${telegramId}, ${symbol}, ${question}, ${answer});
  `;
}

export async function getAnalysisHistory(telegramId: string, limit = 20) {
  const { rows } = await sql`
    SELECT symbol, question, answer, created_at
    FROM analysis_history
    WHERE telegram_id = ${telegramId}
    ORDER BY created_at DESC
    LIMIT ${limit};
  `;
  return rows;
}

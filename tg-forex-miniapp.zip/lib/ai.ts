const SYSTEM_PROMPT = `تو یک دستیار تحلیل بازار فارکس هستی. تحلیل‌های خودت را کوتاه، ساختاریافته و مبتنی بر مفاهیم عمومی تحلیل تکنیکال/فاندامنتال ارائه بده.
همیشه در انتهای پاسخ این جمله را دقیقاً بیاور: «این تحلیل صرفاً جنبه آموزشی دارد و توصیه مالی نیست.»
اگر داده لحظه‌ای قیمت در اختیارت نیست، این را صادقانه بگو و تحلیل را بر اساس اصول کلی و ورودی کاربر بنا کن.`;

export async function generateAnalysis(userPrompt: string): Promise<string> {
  const anthropicKey = process.env.ANTHROPIC_API_KEY;
  const openaiKey = process.env.OPENAI_API_KEY;

  if (anthropicKey) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": anthropicKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 800,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: userPrompt }],
      }),
    });
    if (!res.ok) throw new Error(`Anthropic API error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    const text = data.content?.map((c: any) => c.text || "").join("\n") ?? "";
    return text.trim();
  }

  if (openaiKey) {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        max_tokens: 800,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt },
        ],
      }),
    });
    if (!res.ok) throw new Error(`OpenAI API error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return (data.choices?.[0]?.message?.content ?? "").trim();
  }

  throw new Error(
    "هیچ کلید API‌ای تنظیم نشده است. یکی از ANTHROPIC_API_KEY یا OPENAI_API_KEY را در تنظیمات محیطی Vercel اضافه کنید."
  );
}

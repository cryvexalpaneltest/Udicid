// ساعات استاندارد سشن‌های معاملاتی فارکس بر اساس UTC (بدون احتساب تغییرات ساعت تابستانی/زمستانی)
// می‌توانید این اعداد را بر اساس منبع مرجع دلخواه خودتان تنظیم کنید.
export type SessionDef = {
  id: string;
  nameFa: string;
  color: string;
  startHourUTC: number; // 0-23
  endHourUTC: number; // 0-23
};

export const SESSIONS: SessionDef[] = [
  { id: "sydney", nameFa: "سیدنی", color: "#a78bfa", startHourUTC: 22, endHourUTC: 7 },
  { id: "tokyo", nameFa: "توکیو", color: "#f472b6", startHourUTC: 0, endHourUTC: 9 },
  { id: "london", nameFa: "لندن", color: "#3ddc97", startHourUTC: 8, endHourUTC: 17 },
  { id: "newyork", nameFa: "نیویورک", color: "#f0b90b", startHourUTC: 13, endHourUTC: 22 },
];

export type SessionStatus = {
  id: string;
  isOpen: boolean;
  msUntilChange: number;
  changeType: "open" | "close";
};

function buildIntervals(session: SessionDef, now: Date) {
  const intervals: { start: Date; end: Date }[] = [];
  let durationHours = session.endHourUTC - session.startHourUTC;
  if (durationHours <= 0) durationHours += 24;

  for (let dayOffset = -1; dayOffset <= 2; dayOffset++) {
    const start = new Date(
      Date.UTC(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate() + dayOffset,
        session.startHourUTC,
        0,
        0,
        0
      )
    );
    const end = new Date(start.getTime() + durationHours * 3600 * 1000);
    intervals.push({ start, end });
  }
  return intervals;
}

export function getSessionStatus(session: SessionDef, now: Date): SessionStatus {
  const intervals = buildIntervals(session, now);
  const current = intervals.find((iv) => now >= iv.start && now < iv.end);

  if (current) {
    return {
      id: session.id,
      isOpen: true,
      msUntilChange: current.end.getTime() - now.getTime(),
      changeType: "close",
    };
  }

  const upcoming = intervals
    .filter((iv) => iv.start.getTime() > now.getTime())
    .sort((a, b) => a.start.getTime() - b.start.getTime())[0];

  return {
    id: session.id,
    isOpen: false,
    msUntilChange: upcoming.start.getTime() - now.getTime(),
    changeType: "open",
  };
}

export function formatDuration(ms: number): string {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0f14",
        panel: "#121821",
        panel2: "#161d29",
        border: "#232b38",
        accent: "#3ddc97",
        accent2: "#f0b90b",
        danger: "#ef4444",
        muted: "#8b96a5",
      },
      fontFamily: {
        vazir: ["var(--font-vazir)", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};
export default config;

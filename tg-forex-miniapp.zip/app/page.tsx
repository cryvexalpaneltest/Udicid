"use client";

import { useState } from "react";
import TelegramProvider, { useTelegram } from "@/components/TelegramProvider";
import SessionTimer from "@/components/SessionTimer";
import AIAnalysisTab from "@/components/AIAnalysisTab";
import OtherAnalysisTab from "@/components/OtherAnalysisTab";
import ProfileTab from "@/components/ProfileTab";
import TabBar, { TabId } from "@/components/TabBar";

function AppShell() {
  const { ready, error, profile } = useTelegram();
  const [tab, setTab] = useState<TabId>("sessions");

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted text-sm">
        در حال بارگذاری...
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6 text-center">
        <div className="glass rounded-xl2 p-6 max-w-sm">
          <div className="text-2xl mb-2">⚠️</div>
          <p className="text-sm text-gray-200">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24 px-4 pt-5 max-w-md mx-auto">
      <header className="mb-5">
        <h1 className="text-lg font-bold text-gray-50">سشن‌های بازار فارکس</h1>
        {profile && (
          <p className="text-xs text-muted mt-0.5">
            خوش آمدی {profile.first_name || "کاربر"} 👋
          </p>
        )}
      </header>

      {tab === "sessions" && <SessionTimer />}
      {tab === "ai" && <AIAnalysisTab />}
      {tab === "other" && <OtherAnalysisTab />}
      {tab === "profile" && <ProfileTab />}

      <TabBar active={tab} onChange={setTab} />
    </div>
  );
}

export default function Page() {
  return (
    <TelegramProvider>
      <AppShell />
    </TelegramProvider>
  );
}

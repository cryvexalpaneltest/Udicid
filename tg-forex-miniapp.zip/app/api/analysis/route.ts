import { NextRequest, NextResponse } from "next/server";
import { verifyTelegramInitData } from "@/lib/telegramAuth";
import { generateAnalysis } from "@/lib/ai";
import { ensureSchema, saveAnalysis } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { initData, symbol, question } = await req.json();
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return NextResponse.json({ error: "TELEGRAM_BOT_TOKEN تنظیم نشده است." }, { status: 500 });
    }
    const verified = verifyTelegramInitData(initData, botToken);
    if (!verified) {
      return NextResponse.json({ error: "initData نامعتبر است." }, { status: 401 });
    }
    if (!symbol) {
      return NextResponse.json({ error: "نماد ارزی/جفت‌ارز مشخص نشده." }, { status: 400 });
    }

    const prompt = `نماد/جفت‌ارز: ${symbol}\nسوال یا زمینه کاربر: ${question || "یک تحلیل کلی کوتاه‌مدت بده"}`;
    const answer = await generateAnalysis(prompt);

    await ensureSchema();
    await saveAnalysis(String(verified.user.id), symbol, question ?? null, answer);

    return NextResponse.json({ answer });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "خطای داخلی" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { verifyTelegramInitData } from "@/lib/telegramAuth";
import { getUser, updateUserSettings, getAnalysisHistory } from "@/lib/db";

function authOrFail(initData: string) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) throw new Error("TELEGRAM_BOT_TOKEN تنظیم نشده است.");
  const verified = verifyTelegramInitData(initData, botToken);
  if (!verified) throw new Error("initData نامعتبر است.");
  return verified;
}

export async function POST(req: NextRequest) {
  try {
    const { initData, settings } = await req.json();
    const verified = authOrFail(initData);
    const id = String(verified.user.id);
    const profile = await updateUserSettings(id, settings ?? {});
    return NextResponse.json({ profile });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const initData = req.nextUrl.searchParams.get("initData") ?? "";
    const verified = authOrFail(initData);
    const id = String(verified.user.id);
    const [profile, history] = await Promise.all([
      getUser(id),
      getAnalysisHistory(id),
    ]);
    return NextResponse.json({ profile, history });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}

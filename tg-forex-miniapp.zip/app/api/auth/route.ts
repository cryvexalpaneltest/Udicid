import { NextRequest, NextResponse } from "next/server";
import { verifyTelegramInitData } from "@/lib/telegramAuth";
import { ensureSchema, upsertUser } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { initData } = await req.json();
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      return NextResponse.json(
        { error: "TELEGRAM_BOT_TOKEN تنظیم نشده است." },
        { status: 500 }
      );
    }

    const verified = verifyTelegramInitData(initData, botToken);
    if (!verified) {
      return NextResponse.json({ error: "initData نامعتبر است." }, { status: 401 });
    }

    await ensureSchema();
    const profile = await upsertUser(verified.user);

    return NextResponse.json({ profile });
  } catch (err: any) {
    return NextResponse.json({ error: err.message ?? "خطای داخلی" }, { status: 500 });
  }
}

-- این اسکیما به‌صورت خودکار توسط برنامه (lib/db.ts -> ensureSchema) ساخته می‌شود.
-- نگه‌داشتن این فایل فقط برای مرجع و اجرای دستی در صورت نیاز است.

CREATE TABLE IF NOT EXISTS users (
  telegram_id TEXT PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  last_name TEXT,
  photo_url TEXT,
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS analysis_history (
  id SERIAL PRIMARY KEY,
  telegram_id TEXT NOT NULL REFERENCES users(telegram_id),
  symbol TEXT NOT NULL,
  question TEXT,
  answer TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
